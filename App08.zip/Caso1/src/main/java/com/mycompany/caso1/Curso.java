package com.mycompany.caso1;

public class Curso {
    
    private String nombre;
    private int aula;
    private String horario;
    private Nivel nivel;

    public Curso(String nombre, int aula, String horario, Nivel nivel) {
        this.nombre = nombre;
        this.aula = aula;
        this.horario = horario;
        this.nivel = nivel;
    }
    
    public void registrarProgreso() {
        System.out.println("Se registro el progreso correcto en el curso " + nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAula() {
        return aula;
    }

    public void setAula(int aula) {
        this.aula = aula;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public Nivel getNivel() {
        return nivel;
    }

    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }
    
    
}
