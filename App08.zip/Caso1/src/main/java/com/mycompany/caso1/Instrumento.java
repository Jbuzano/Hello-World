package com.mycompany.caso1;

public class Instrumento {
    
    private String nombre;
    private String marca;
    private Categoria categoria;
    private Estado estado;

    public Instrumento(String nombre, String marca, Categoria categoria, Estado estado) {
        this.nombre = nombre;
        this.marca = marca;
        this.categoria = categoria;
        this.estado = estado;
    }
    
    public void asignar(Estudiante estudiante) {
        System.out.println(nombre + " esta asignado a " + estudiante.getNombre());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    
    
    
}
