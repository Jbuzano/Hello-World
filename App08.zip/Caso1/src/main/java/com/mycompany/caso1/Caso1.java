package com.mycompany.caso1;

public class Caso1 {

    public static void main(String[] args) {
        
        Curso curso1 = new Curso("Canto", 15, "9am", Nivel.Basico);
        Curso curso2 = new Curso("Curso de Piano", 16, "10pm", Nivel.Avanzado);
        
        Estudiante estudiante1 = new Estudiante("Juan", 20, 100, curso2);
        Estudiante estudiante2 = new Estudiante("Alex", 15, 101, curso1);
        
        Instrumento instrumento1 = new Instrumento("Piano", "XR", Categoria.Teclado, Estado.Disponible);
        Instrumento instrumento2 = new Instrumento("Violin", "XR", Categoria.Cuerda, Estado.En_mantenimiento);
         
        curso1.registrarProgreso();
        estudiante1.matricularse();
        instrumento1.asignar(estudiante2);
        
                
    }
}
