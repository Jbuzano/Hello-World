package com.mycompany.caso1;

public enum Nivel {
    Basico, Intermedio, Avanzado
}
