package com.mycompany.caso1;

public enum Categoria {
    Cuerda, Percusión, Viento, Teclado
}
