package com.mycompany.caso1;

public enum Estado {
    Disponible, En_mantenimiento, Fuera_de_servicio
}
