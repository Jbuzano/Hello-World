package com.mycompany.caso1;

public class Estudiante {

    private String nombre;
    private int edad;
    private int numeroMatricula;
    private Curso curso;

    public Estudiante(String nombre, int edad, int numeroMatricula, Curso curso) {
        this.nombre = nombre;
        this.edad = edad;
        this.numeroMatricula = numeroMatricula;
        this.curso = curso;
    }
    
    public void matricularse() {
        System.out.println(nombre + " se ha matruculado en " + curso.getNombre());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getNumeroMatricula() {
        return numeroMatricula;
    }

    public void setNumeroMatricula(int numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }
    
    

}
