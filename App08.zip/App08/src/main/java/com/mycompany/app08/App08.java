package com.mycompany.app08;

import java.util.Random;
import javax.swing.JOptionPane;

/*
SEMANA #08
TEMA: Arreglos.
*/
public class App08 {

    public static void main(String[] args) {
        
        System.out.println("---- Arreglos ----");
        
        // Declarar un Arreglo / Lista / Vector
        
        int edades[] = new int[5];
        
        int edad = 53;
        
        // Modificar la informacion:
        edades[2] = 21;
        edades[0] = 8;
        edades[1] = edad;
        edades[4] = edades[2] - edades[0];
        edades[4] = edad + 2;
        
        // edades[10] = 10; ArrayIndexOutOfBoundsException
        
        // Obtener la informacion:
        System.out.println("La edad en el indice 0 es: " + edades[0]);
        System.out.println("La edad en el indice 1 es: " + edades[1]);
        System.out.println("La edad en el indice 2 es: " + edades[2]);
        System.out.println("La edad en el indice 3 es: " + edades[3]);
        System.out.println("La edad en el indice 4 es: " + edades[4]);
        System.out.println();
        
        String[] nombres = new String[3];
        
        nombres[0] = "Alex";
        nombres[1] = "Fabian";
        nombres[2] = "Daniela";
        
        System.out.println("El primer nombre es: " + nombres[0]);
        System.out.println("El segundo nombre es: " + nombres[1]);
        System.out.println("El tercer nombre es: " + nombres[2]);
        
        String apellidos[] = {"Campos", "Gomez", "Herrera", "Perez"};
        
        apellidos[1] = "Mora";
        
        System.out.println("\nHola " + nombres[2] + " " + apellidos[3]);
        
        Random random = new Random();
        
        int indiceNombre = random.nextInt(0, 3);
        int indiceApellido = random.nextInt(0, 4);
        
        System.out.println("\nSu nombre completo es: " + nombres[indiceNombre] 
                + " " + apellidos[indiceApellido]);
        
        // Recorrer un Arreglo:
        
//        for (int i = 0; i < 5; i++) {
//            edades[i] = Integer.parseInt(JOptionPane.showInputDialog(
//                    "Ingrese la edad #" + (i + 1)));
//        }
//        
//        for (int i = 0; i < 5; i++) {
//            System.out.println("La edad #" + (i + 1) + " es: " + edades[i]);
//        }
        
        String nombreBuscar = JOptionPane.showInputDialog(
                "Ingrese el nombre a buscar");
        
        for (int i = 0; i < 3; i++) {
            if (nombreBuscar.equals(nombres[i])) {
                System.out.println("Si esta el nombre: " 
                        + nombres[i] + " esta en el indice: " + i);
            }
        }
        
        // Usar un ciclo para modificar todas las edades por nuevas edades
        // random de 5 años minimo y maximo 92 años, luego otro ciclo
        // recorriendo el arreglo para mostrar las nuevas edades:
        
        for (int i = 0; i < edades.length; i++) {
            edades[i] = random.nextInt(5, 93);
        }
        
        for (int i = 0; i < edades.length; i++) {
            System.out.println("La edad es: " + edades);
        }
        
        
        
        
    }
}
